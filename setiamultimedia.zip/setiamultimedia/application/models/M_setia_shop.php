<?php

	/**
	* 
	*/
	class M_setia_shop extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function cek_diskon(){
			return $this->db->get('table_barang');
		}

		function tampil_barang(){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.kategori = 'Handphone'");
		}

		function getData($id){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.id_barang = '$id'");
		}

		function tampil_dengan_diskon(){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang INNER JOIN table_promo ON table_barang.id_barang = table_promo.id_barang where table_detail_barang.status_gambar = 'Utama'");
		}

		function tampil_grosir_pulsa(){
			return $this->db->get('table_grosir');
		}

		function tampil_semua_product(){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' ORDER BY RAND() LIMIT 8 ");
		}

		function pencarian_barang($where, $kategori){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.nama_barang LIKE '%$where%' AND table_barang.kategori LIKE '%$kategori%'");
		}

		function tampil_slide(){
			return $this->db->get('table_slider');
		}

		function tampil_detail_barang($where){
			$this->db->where('id_barang', $where);
			return $this->db->get('table_barang');;
		}

		function tampil_detail_gambar($where){
			$this->db->where('id_barang', $where);
			return $this->db->get('table_detail_barang');
		}

		function tampil_kategori(){
			return $this->db->get('table_kategori');
		}

		function tampil_sesuai_product($where){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.kategori LIKE '%$where%'");
		}

		function tampil_product(){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' ORDER BY table_barang.id_barang ASC");
		}

		function tampil_paket(){
			return $this->db->query("SELECT * from table_pulsa where jenis_pulsa = 'Paket Data'");
		}

		function tampil_pulsa(){
			return $this->db->query("SELECT * from table_pulsa where jenis_pulsa = 'Pulsa'");
		}

		function simpan_user($value){
			return $this->db->insert('table_user', $value);
		}

		function proses_login($where){
			return $this->db->get_where('table_user', $where);
		}

		function tampil_profile(){
			return $this->db->get('perusahaan');
		}

		function proses_filter_harga($where, $harga_murah, $harga_mahal){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.kategori LIKE '%$where%' AND table_barang.harga BETWEEN $harga_murah AND $harga_mahal");
		}

		function data_barang($where, $harga_murah, $harga_mahal, $number, $offer){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.kategori LIKE '%$where%' AND table_barang.harga BETWEEN $harga_murah AND $harga_mahal LIMIT $offer, $number");
		}

		function filter_pencarian_barang($where, $kategori, $harga_murah, $harga_mahal){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.nama_barang LIKE '%$where%' AND table_barang.kategori LIKE '%$kategori%' AND table_barang.harga BETWEEN $harga_murah AND $harga_mahal");
		}

		function simpan_langganan($value){
			return $this->db->insert('table_langganan', $value);
		}

	    function tampil_pulsaregax(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'AXIS' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulsaregxl(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'XL' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulsaregtelkom(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'TELKOMSEL' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulsaregindo(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'INDOSAT' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulsaregthr(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'THREE' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulsaregsmr(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'SMART' AND `jenis_grosir` LIKE 'Pulsa Reguler' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadaindo_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'INDOSATDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadatelkom_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'TELKOMSELDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadaax_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'AXISDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadaxl_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'XLDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadathr_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'THREEDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpadasmr_data(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'SMARTDATA' AND `jenis_grosir` LIKE 'Pulsa Paket Data' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pultran_etoll(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'ETOLL' AND `jenis_grosir` LIKE 'Pulsa Transportasi' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pultran_gojek(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'GOJEK' AND `jenis_grosir` LIKE 'Pulsa Transportasi' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pultran_godriv(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'GOJEKDRIVER' AND `jenis_grosir` LIKE 'Pulsa Transportasi' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pultran_grab(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'GRAB' AND `jenis_grosir` LIKE 'Pulsa Transportasi' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpasms_indosms(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'INDOSATSMS' AND `jenis_grosir` LIKE 'Pulsa Paket SMS' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpasms_telkomsms(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'TELKOMSELSMS' AND `jenis_grosir` LIKE 'Pulsa Paket SMS' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpatel_indotel(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'INDOSATTELEPON' AND `jenis_grosir` LIKE 'Pulsa Paket Telepon' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpatel_telkomtel(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'TELKOMSELTELEPON' AND `jenis_grosir` LIKE 'Pulsa Paket Telepon' ORDER BY `id` ASC");
	    }
	    
	    function tampil_pulpatel_xltel(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'XLTELEPON' AND `jenis_grosir` LIKE 'Pulsa Paket Telepon' ORDER BY `id` ASC");
	    }
	    
	    function tampil_toli_pln(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'PLN' AND `jenis_grosir` LIKE 'Token Listrik' ORDER BY `id` ASC");
	    }
	    
	    function tampil_voucda_isadata(){
	        return $this->db->query("SELECT *  FROM `table_grosir` WHERE `kartu` LIKE 'VOUCHERINDOSATDATA' AND `jenis_grosir` LIKE 'Voucher Data' ORDER BY `id` ASC");
	    }
	    
	}

?>