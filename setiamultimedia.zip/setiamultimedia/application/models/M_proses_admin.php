<?php

	/**
	* 
	*/
	class M_proses_admin extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function simpan_barang($value){
			return $this->db->insert('table_barang', $value);
		}

		function simpan_gambar($value){
			return $this->db->insert('table_detail_barang', $value);
		}

		function tampil_barang(){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama'");
		}

		function tampil_brosur(){
			return $this->db->get('table_brosur');
		}

		function edit_brosur($data, $id){
			$this->db->where('id_brosur', $id);
			return $this->db->update('table_brosur', $data);
		}

		function simpan_kategori($value){
			return $this->db->insert('table_kategori', $value);
		}

		function simpan_grosir($value){
			return $this->db->insert('table_grosir', $value);
		}
		
		function edit_grosir($value, $kode){
			$this->db->where('id', $kode);
			return $this->db->update('table_grosir', $value);
		}
		
		function pencarian_produk($where){
			$this->db->where('kode_produk', $where);
			return $this->db->get('table_grosir');
		}

		function simpan_slider($value){
			return $this->db->insert('table_slider', $value);
		}

		function tampil_gambar_barang($id_barang){
			return $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_barang.id_barang = '$id_barang'");
		}

		function tampil_kode_nomor_barang(){
			return $this->db->query("SELECT * FROM table_barang ORDER BY id_barang DESC");
		}

		function tampil_kategori(){
			return $this->db->get('table_kategori');
		}

		function tampil_slider(){
			return $this->db->get('table_slider');
		}

		function tampil_edit_product($where){
			$this->db->where('id_barang', $where);
			return $this->db->get('table_barang');
		}

		function tampil_edit_gambar($where){
			$this->db->where('id_detail_barang', $where);
			return $this->db->get('table_detail_barang');
		}

		function tampil_promo_barang(){
			return $this->db->query('SELECT * FROM table_promo INNER JOIN table_barang ON table_promo.id_barang = table_barang.id_barang');
		}

		function tampil_edit_kategori($where){
			$this->db->where('id_kategori', $where);
			return $this->db->get('table_kategori');
		}

		function tampil_profile(){
			return $this->db->get('perusahaan');
		}

		function edit_kategori($value, $where){
			$this->db->where('id_kategori', $where);
			return $this->db->update('table_kategori', $value);
		}

		function edit_gambar($value, $where){
			$this->db->where('id_detail_barang', $where);
			return $this->db->update('table_detail_barang', $value);
		}

		function hapus_gambar($where){
			$this->db->where('id_detail_barang', $where);
			return $this->db->delete('table_detail_barang');
		}

		function hapus_product($where){
			$this->db->where('id_barang', $where);
			return $this->db->delete('table_barang');
		}

		function hapus_grosir($where){
			$this->db->where('id', $where);
			return $this->db->delete('table_grosir');
		}

		function hapus_semua_gambar($where){
			$this->db->where('id_barang', $where);
			return $this->db->delete('table_detail_barang');
		}


		function edit_barang($value, $where){
			$this->db->where('id_barang', $where);
			return $this->db->update('table_barang', $value);
		}

		function edit_detail_barang($value, $where){
			$this->db->where('id_barang', $where);
			return $this->db->update('table_detail_barang', $value);
		}

		function simpan_pulsa($where){
			return $this->db->insert('table_pulsa', $where);
		}

		function tampil_pulsa(){
			return $this->db->get('table_grosir');
		}

		function tampil_cari_barang($where){
			$this->db->where('id_barang', $where);
			return $this->db->get('table_barang');
		}

		function cek_barang_promo($where){
			$this->db->where('id_barang', $where);
			return $this->db->get('table_promo');
		}

		function simpan_promo($where){
			return $this->db->insert('table_promo', $where);
		}

		function update_status_promo_barang($value, $where){
			$this->db->where('id_barang', $where);
			return $this->db->update('table_barang', $value);
		}

		function edit_profile($value, $where){
			$this->db->where('id_perusahaan', $where);
			return $this->db->update('perusahaan', $value);
		}
		
		function tampil_grosir_edit($id){
		    $this->db->where('id', $id);
		    return $this->db->get('table_grosir');
		}
	}

?>