<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<!-- 
        Awesome Template
        http://www.templatemo.com/preview/templatemo_450_awesome
        -->
		<title>Setia Multimedia - Grosir Pulsa</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="<?php echo base_url();?>assets/grosir/css/animate.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/grosir/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/grosir/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/grosir/css/custom.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="<?php echo base_url();?>assets/grosir/css/templatemo-style.css">
		<script src="<?php echo base_url();?>assets/grosir/js/jquery.js"></script>
		<script src="<?php echo base_url();?>assets/grosir/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/grosir/js/jquery.singlePageNav.min.js"></script>
		<script src="<?php echo base_url();?>assets/grosir/js/typed.js"></script>
		<script src="<?php echo base_url();?>assets/grosir/js/wow.min.js"></script>
		<script src="<?php echo base_url();?>assets/grosir/js/custom.js"></script>
        <script type="text/javascript">
            function home(){
                document.location = "index";
            }
        </script>
	</head>
	<body id="top">

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

        <!-- start header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <p><i class="fa fa-phone"></i><span> Phone</span>085108332222</p>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <p><i class="fa fa-envelope-o"></i><span> Email</span><a href="#">serversetia@gmail.com</a></p>
                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->

    	<!-- start navigation -->
		<nav class="navbar navbar-default templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" onclick="home()" style="width: 170px; cursor: pointer;">
				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#top">HOME</a></li>
						<li><a href="#about">TENTANG KAMI</a></li>
						<li><a href="#service">PRODUK</a></li>
						<li><a href="#team">TRANSAKSI</a></li>
						<li><a href="#rekening">REKENING PEMBAYARAN</a></li>
						<li><a href="#contac  t">KONTAK</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- end navigation -->

    	<!-- start home -->
    	<section id="home">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-offset-2 col-md-8">
    					<h1 class="wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">SELAMAT DATANG di  <span><img src="<?php echo base_url();?>assets/img/Untitled-2.png" width="50%"></span></h1>
    					<div class="element">
                            <div class="sub-element">Penyedia Kartu perdana yang paling berkualitas dan terpercaya.</div>
                            <div class="sub-element">Melayani anda dengan kepercayaan yang tinggi dan anda kan mendapatkan pelayanan terbaik kami.</div>
                            <div class="sub-element">Transaksi cepat, harga bersahabat</div>
                        </div>
    					<a data-scroll href="#contact" class="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">Info Lebih Lanjut</a>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end home -->

    	<!-- start about -->
		<section id="about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">TENTANG <span>KAMI</span></h2>
    				</div>
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-comment-o"></i>
								</div>
								<h3 class="media-heading">SETIA MULTIMEDIA</h3>
							</div>
							<div class="media-body">
								<p>SETIA MULTIMEDIA adalah tempat wahana untuk penjualan aksesoris, pulsa, kartu perdana dan handphone di mana harganya sangatlah lebih murah dari tempat lainnya, mari silahkan beli sebelum kalian ketinggalan</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- end about -->

    	<!-- start service -->
    	<section id="service">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">DISTRIBUTOR <span>PRODUK</span> KAMI</h2>
    				</div>
    				
                    <div class="col-md-12 active wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">
                        <h4>Pulsa Paket SMS</h4>
                        <p>
                            <table width="100%" id="tempat_grosir">
                                <tr class="table-header">
                                    <th>Kode</th>
                                    <th>Kartu</th>
                                    <th>Nominal</th>
                                    <th>Keterangan</th>
                                    <th>Masa Aktif</th>
                                    <th>Poin</th>
                                </tr>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA REGULER</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregax as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregxl as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregtelkom as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregindo as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregthr as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregsmr as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET DATA</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaindo_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadatelkom_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaax_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaxl_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadathr_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadasmr_data as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA TRANSPORTASI</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_etoll as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_gojek as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_godriv as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_grab as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET SMS</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpasms_indosms as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpasms_telkomsms as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET TELPON</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_indotel as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_telkomtel as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_xltel as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>TOKEN LISTRIK</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datatoli_pln as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr class="table-data">
                                    <td colspan="2" style="padding-left:20px;"><b>VOUCHER DATA</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datavoucda_isadata as $data) {
                                        $no++;
                                ?>
                                            <tr class="table-data">
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                            </tr>
                                <?php
                                    }
                                ?>
                            </table>
                        </p>
                    </div>
    			</div>
    		</div>
    	</section>
    	<!-- end servie -->

        <!-- start team -->
        <section id="team">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>INFORMASI</span> & CARA TRANSAKSI</h2>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
                        <div class="team-wrapper">
                            <div class="team-des">
                                <h3><span>Informasi & Cara Transaksi</span></h3>
                                <p><?php echo $brosur['detail'];?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end team -->

        <!-- start team -->
        <section id="rekening">
            <div id="team">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>REKENING</span> PEMBAYARAN</h2>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
                        <div class="team-wrapper">
                            <img src="<?php echo base_url();?>assets/grosir/images/BRI.jpg" class="img-responsive" alt="BRI" style="width: 100%; height: 100px;">
                                <div class="team-des">
                                    <h4>Rekening BRI</h4>
                                    <span>SUSI PRIHATININGATI</span>
                                    <p>No. Rek 051601000708562
                                    
                                    </p>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
                        <div class="team-wrapper">
                            <img src="<?php echo base_url();?>assets/grosir/images/BCA.jpg" class="img-responsive" alt="BCA" style="width: 100%; height: 100px;">
                                <div class="team-des">
                                    <h4>Rekening BCA</h4>
                                    <span>SUSI PRIHATININGATI</span>
                                    <p>No. Rek 1230 577 176</p>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
                    </div>
                </div>
            </div>
        </div>
        </section>
        <!-- end team -->

<!-- start about -->
        <section id="contact">
            <div id="about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">HUBUNGI <span>KAMI</span></h2>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="media">
                            <div class="media-heading-wrapper">
                                <div class="media-object pull-left">
                                    <i class="fa fa-mobile"></i>
                                </div>
                                <h3 class="media-heading">CS & PENDAFTARAN</h3>
                            </div>
                            <div class="media-body">
                                <p>
                                    <span><i class="fa fa-whatsapp"></i> <b>Telpon / WA</b> : &nbsp; 085108332222</span>
                                </p>
                                <p>
                                    <span><i class="fa fa-whatsapp"></i> <b>Telegram</b> : &nbsp; @setiaservercs</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
                        <div class="media">
                            <div class="media-heading-wrapper">
                                <div class="media-object pull-left">
                                    <i class="fa fa-comment-o"></i>
                                </div>
                                <h3 class="media-heading">CENTER TRANSAKSI</h3>
                            </div>
                            <div class="media-body">
                                <p>
                                    <span><i class="fa fa-arrows"></i> <b>SMS</b> : &nbsp; 085280528055, 085708228055, 085262778055, 082257638055, 085880858055, 085733178055</span>
                                </p>
                                <p>
                                    <span><i class="fa fa-whatsapp"></i> <b>Telegram</b> : &nbsp; setiaserverbot</span>
                                </p>
                                <p>
                                    <span><i class="fa fa-whatsapp"></i> <b>Telpon / WA</b> : &nbsp; 085280528055</span>
                                </p>
                                <p>
                                    <span><i class="fa fa-square"></i> <b>Jabber</b> : &nbsp; setiaserver@jabbim.com,  setiaserver2@jabber.at, setiaserver3@jabb3r.org</span>
                                </p>
                                <p>
                                    <span><i class="fa fa-square"></i> <b>Gtalk</b> : &nbsp; serversetia@gmail.com</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </section>
        <!-- end contact -->


        <!-- start copyright -->
        <footer id="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">
                       	Copyright &copy; 2084 Company Name</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end copyright -->

	</body>
</html>