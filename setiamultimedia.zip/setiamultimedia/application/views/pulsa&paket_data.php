<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>SETIA MULTIMEDIA - Pulsa & Paket Data</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick.css" />
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" />
    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/Admin layout/css/helper.css" rel="stylesheet">
    
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<div id="top-header">
			<div class="container">
				<div class="container">
					<div class="pull-left">
						<span>Welcome to SETIA SHOP!</span>
					</div>
					<div class="pull-right">
						<span><i class="fa fa-phone"></i> &nbsp; <?php echo $perusahaan['kontak_1'];?></span>
					</div>
				</div>
			</div>
		</div>
		<!-- /top Header -->

		<!-- header -->
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<!-- Logo -->
					<div class="header-logo">
						<a class="logo" href="<?php echo site_url('Welcome/index');?>">
							<img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" style="width: 250px;" alt="">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Search -->
					<div class="header-search">
						<?php echo form_open_multipart('Welcome/proses_cari');?>
							<input class="input search-input" name="cari" type="text" placeholder="Enter your keyword">
							<select class="input search-categories" name="kategori">
								<option>Pilih Semua</option>
								<?php 
									foreach ($kategori as $data_kategori) {
								?>
									<option><?php echo $data_kategori->nama_kategori;?></option>
								<?php
									}
								?>
							</select>
							<button class="search-btn"><i class="fa fa-search"></i></button>
						<?php echo form_close();?>
					</div>
					<!-- /Search -->
				</div>
			</div>
			<!-- header -->
		</div>
		<!-- container -->
	</header>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav show-on-click">
					<span class="category-header">Categories <i class="fa fa-list"></i></span>
					<ul class="category-list">						
						<li><a href="#">Pulsa Operator</a></li>
						<?php 
							foreach ($kategori as $data_kategori) {
						?>
							<li><a href="<?php echo site_url('Welcome/product');?>/<?php echo $data_kategori->nama_kategori;?>"><?php echo $data_kategori->nama_kategori;?></a></li>
						<?php
							}
						?>
					</ul>
				</div>
				<!-- /category nav -->

			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li class="active">Products</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- ASIDE -->
				<div id="aside" class="col-md-3">

					<!-- aside widget -->
					<div class="aside">
						<?php echo form_open_multipart();?>
						<h3 class="aside-title">Filter by Price</h3>
						<select name="nama_operator" class="form-control col-md-12">
                            <option>All Operator</option>
                            <option>XL</option>
                      	      <option>Telkomsel</option>
                            <option>TRI</option>
                            <option>Smartfren</option>
                            <option>Indosat</option>
                            <option>Axis</option>
                            <option>Bolt</option>
                        </select>
						<br><br>
						<button type="submit" class="primary-btn">Cari</button>
						<?php echo form_close();?>
					</div>
					<!-- aside widget -->

				</div>
				<!-- /ASIDE -->

				<!-- MAIN -->
				<div id="main" class="col-md-9">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body p-b-0">
                                <h3 class="card-title">Daftar Paket Data & Pulsa</h3>
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs customtab" role="tablist">
                                    <li class="nav-item active col-sm-6"> <a class="nav-link" data-toggle="tab" href="#home2" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">Paket Data</span></a> </li>
                                    <li class="nav-item col-sm-6"> <a class="nav-link" data-toggle="tab" href="#profile2" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Pulsa</span></a> </li>
                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <div class="tab-pane active" id="home2" role="tabpanel">
                                        <div class="p-20">
                                        	<div class="card-body">
				                                <div class="table-responsive">
				                                    <table class="table table-striped">
				                                        <thead>
				                                            <tr>
				                                                <th>#</th>
				                                                <th>Nama Operator</th>
				                                                <th>Paket Data</th>
				                                                <th>Harga</th>
				                                            </tr>
				                                        </thead>
				                                        <tbody>
				                                        	<?php 
				                                        		$no = 0;
				                                        		foreach ($paket as $data_paket) {
				                                        		$no++;
				                                        	?>
				                                        		<tr>
					                                                <th scope="row"><?php echo $no;;?></th>
					                                                <td><?php echo $data_paket->nama_operator;?></td>
					                                                <td><?php echo $data_paket->jumlah_pulsa_atau_data;?></td>
					                                                <td>Rp. <?php echo number_format($data_paket->harga_jual,0, ".",".");?></td>
					                                            </tr>
				                                        	<?php
				                                        		}
				                                        	?>
				                                            
				                                        </tbody>
				                                    </table>
				                                </div>
				                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane p-20" id="profile2" role="tabpanel">
                                    	<div class="card-body">
			                                <div class="table-responsive">
			                                    <table class="table table-striped">
			                                        <thead>
			                                            <tr>
			                                                <th>#</th>
			                                                <th>Nama Operator</th>
			                                                <th>Pulsa</th>
			                                                <th>Harga</th>
			                                            </tr>
			                                        </thead>
			                                        <tbody>
			                                        	<?php 
			                                        		$no = 0;
			                                        		foreach ($pulsa as $data_paket) {
			                                        		$no++;
			                                        	?>
			                                        		<tr>
				                                                <th scope="row"><?php echo $no;;?></th>
				                                                <td><?php echo $data_paket->nama_operator;?></td>
				                                                <td><?php echo number_format($data_paket->jumlah_pulsa_atau_data, 0,".",".");?></td>
				                                                <td>Rp. <?php echo number_format($data_paket->harga_jual,0, ".",".");?></td>
				                                            </tr>
			                                        	<?php
			                                        		}
			                                        	?>
			                                            
			                                        </tbody>
			                                    </table>
			                                </div>
			                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<!-- /store bottom filter -->
				</div>
				<!-- /MAIN -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
	<footer id="footer" class="section section-grey">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<!-- footer logo -->
						<div class="footer-logo">
							<a class="logo" href="<?php echo site_url('Welcome/index');?>">
					            <img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" alt="">
				          	</a>
						</div>
						<!-- /footer logo -->

						<p><?php echo $perusahaan['tentang_perusahaan'];?></p>
					</div>
				</div>
				<!-- /footer widget -->

				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">Hubungi Kami</h3>
						<ul class="list-links">
							<li><a><i class="fa fa-phone"></i> &nbsp;&nbsp; <?php echo $perusahaan['kontak_1'];?></a></li>
							<li><a><i class="fa fa-map-marker"></i> &nbsp;&nbsp; <?php echo $perusahaan['alamat_perusahaan'];?></a></li>
							<li><a><i class="fa fa-envelope-square"></i> &nbsp;&nbsp; <?php echo $perusahaan['email'];?></a></li>
							<li><a><i class="fa fa-facebook"></i> &nbsp;&nbsp; <?php echo $perusahaan['facebook'];?></a></li>
						</ul>
					</div>
				</div>
				<!-- /footer widget -->

				<div class="clearfix visible-sm visible-xs"></div>

				<!-- footer subscribe -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">BERLANGGANAN</h3>
						<p>Dengan mendaftar anda akan mendapatkan info promo, diskon & produk terbaru dari Setia Shop.</p>
						<div class="form-group">
							<input class="input" id="email" onkeyup="validateEmail(this);" name="email" placeholder="Enter Email Address">
							<p style="color: #f00; display: none;"  id="pesan">Silahkan masukkan email anda</p>
						</div>
						<button onclick="berlangganan()" id="btn_langgan" class="primary-btn">YUK BERGABUNG</button>
					</div>
				</div>
				<!-- /footer subscribe -->
			</div>
			<!-- /row -->
			<hr>
			<!-- row -->
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<!-- footer copyright -->
					<div class="footer-copyright">
						Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Design By <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Mr Brohid</a>
					</div>
					<!-- /footer copyright -->
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</footer>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/slick.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/nouislider.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.zoom.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/main.js"></script>
	<script type="text/javascript">

		function validateEmail(emailField){
	        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,3})$/;

	        if (reg.test(emailField.value) == false) 
	        {
	            document.getElementById("btn_langgan").disabled = true;
				$("#pesan").css({"display":"block"});
				$("#pesan").text("Karakter email anda harus terdapat @ dan (.) titik");
	        }else if (reg.test(emailField.value) == true) {
	        	document.getElementById("btn_langgan").disabled = false;
				$("#pesan").css({"display":"none"});
	        }
	        return true;
		}

		function berlangganan(){
			var emails = $("#email").val();
			if (emails == "") {
				$("#pesan").css({"display":"block"});
			}else{
				$.ajax({
					url : "<?php echo site_url('Welcome/simpan_langganan');?>",
					type : "POST",
					data : {
						email : $("#email").val()
					},
					success:function(hasil){
						alert(hasil);
						document.location='<?php echo site_url('Welcome/index');?>';
					}
				});
			}
		}

	</script>
</body>
</html>
