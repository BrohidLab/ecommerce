<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>SETIA MULTIMEDIA</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick.css" />
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
</head>

<body>
	<div id="back_top">
		<img src="<?php echo base_url();?>/assets/icon/back-top.png"  onclick="backtop()" style="width: 24px; height: 24px;" title="Keatas">
	</div>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<div id="top-header">
			<div class="container">
				<div class="pull-left">
					<span>Welcome to <?php echo $perusahaan['nama_perusahaan'];?></span>
				</div>
				<div class="pull-right">
					<span><i class="fa fa-phone"></i> &nbsp; <?php echo $perusahaan['kontak_1'];?></span>
				</div>
			</div>
		</div>
		<!-- /top Header -->

		<!-- header -->
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<!-- Logo -->
					<div class="header-logo">
						<a class="logo" href="<?php echo site_url('Welcome/index');?>">
							<img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" style="width: 250px;" alt="">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Search -->
					<div class="header-search">
						<?php echo form_open_multipart('Welcome/proses_cari');?>
							<input class="input search-input" name="cari" type="text" placeholder="Enter your keyword">
							<select class="input search-categories" name="kategori">
								<option>Pilih Semua</option>
								<?php 
									foreach ($kategori as $data_kategori) {
								?>
									<option><?php echo $data_kategori->nama_kategori;?></option>
								<?php
									}
								?>
							</select>
							<button class="search-btn"><i class="fa fa-search"></i></button>
						<?php echo form_close();?>
					</div>
					<!-- /Search -->
				</div>

				<div class="pull-right">
					<div class="tombol_menu">
						<span onclick="tombol_menu()">
							<p>KATEGORI</p>
							<img src="<?php echo base_url();?>assets/icon/listing-option.png">
						</span>	
					</div>
					<div class="tempat_menu" id="tmp_menu">
						<ul>
							<li>
								<a href="<?php echo site_url('Welcome/grosir_pulsa');?>">
									<img src="<?php echo base_url();?>assets/icon/play-button.png"> Grosir Pulsa
								</a>
							</li>
							<?php 
								foreach ($kategori as $data_kategori) {
							?>
								<li><a href="<?php echo site_url('Welcome/product');?>/<?php echo $data_kategori->nama_kategori;?>">
									<img src="<?php echo base_url();?>assets/icon/play-button.png"><?php echo $data_kategori->nama_kategori;?></a></li>
							<?php
								}
							?>
						</ul>
					</div>
			</div>
			<!-- header -->
		</div>
		<!-- container -->
	</header>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav show-on-click">
					<span class="category-header">Kategori <i class="fa fa-list"></i></span>
					<ul class="category-list">
						<li><a href="<?php echo site_url('Welcome/grosir_pulsa');?>">Grosir Pulsa</a></li>
						<?php 
							foreach ($kategori as $data_kategori) {
						?>
							<li><a href="<?php echo site_url('Welcome/product');?>/<?php echo $data_kategori->nama_kategori;?>"><?php echo $data_kategori->nama_kategori;?></a></li>
						<?php
							}
						?>
					</ul>
				</div>
				<!-- /category nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li><a href="#">Produk</a></li>
				<li>Kategori</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!--  Product Details -->
				<div class="product product-details clearfix">
					<div class="col-md-6">
						<div id="product-main-view">
							<?php
								foreach ($gambar as $data_gambar) {
							?>
								<div class="product-view view_gambar" style=" max-height: 500px; overflow: hidden;">
									<img style=" max-height: 500px; overflow: hidden; " src="<?php echo base_url();?>gambar_product/<?php echo $data_gambar->gambar;?>" alt="" width="100px">
								</div>
							<?php
								}
							?>
						</div>
						<div id="product-view">
							<?php
								foreach ($gambar as $data_gambar) {
							?>
								<div class="product-view" style="max-width: 100px; max-height: 100px; overflow: hidden;">
									<img src="<?php echo base_url();?>gambar_product/<?php echo $data_gambar->gambar;?>" style="max-width: 200px; max-height: 100px; overflow: hidden;" alt="">
								</div>
							<?php
								}
							?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="product-body">
							<div class="product-label">
								<span>New</span>
								<span class="sale">-20%</span>
							</div>
							<h2 class="product-name"><?php echo $barang['nama_barang'];?></h2>
							<h3 class="product-price">Rp. <?php echo number_format($barang['harga'], 0, ".", ".");?></h3>
							<div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="product-tab">
							<ul class="tab-nav">
								<li class="active"><a data-toggle="tab" href="#tab1">Description</a></li>
								<li><a data-toggle="tab" href="#tab1">Details</a></li>
							</ul>
							<div class="tab-content">
								<div id="tab1" class="tab-pane fade in active">
									<p><?php echo $barang['detail_barang'];?></p>
								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- /Product Details -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- section title -->
				<div class="col-md-12">
					<div class="section-title">
						<h2 class="title">Produk yang sama</h2>
					</div>
				</div>
				<!-- section title -->

				<?php 
					$data = $this->db->query("SELECT * FROM table_barang INNER JOIN table_detail_barang ON table_barang.id_barang = table_detail_barang.id_barang where table_detail_barang.status_gambar = 'Utama' AND table_barang.kategori = '$barang[kategori]' ORDER BY RAND() LIMIT 4")->result();

					foreach ($data as $data_barang) {
				?>

				<!-- Product Single -->
				<div class="col-md-3 col-sm-6 col-xs-6">
					<div class="product product-single">
						<div class="product-thumb">
							<button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button>
							<img src="<?php echo base_url();?>gambar_product/<?php echo $data_barang->gambar;?>" alt="" width="100%" height="250px" style="padding: 20px;">
						</div>
						<div class="product-body">
							
							<h4 class="product-price" style="color: #ff6600;">Rp. <?php echo number_format($data_barang->harga,0,".",".");?></h4>
							<h4 class="product-price"><a href="#"><?php echo substr($data_barang->nama_barang, 0, 40);?></a></h4>
						</div>
					</div>
				</div>
				<!-- /Product Single -->

				<?php
					}
				?>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->


	<!-- FOOTER -->
	<footer id="footer" class="section section-grey">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<!-- footer logo -->
						<div class="footer-logo">
							<a class="logo" href="<?php echo site_url('Welcome/index');?>">
					            <img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" alt="">
				          	</a>
						</div>
						<!-- /footer logo -->

						<p><?php echo $perusahaan['tentang_perusahaan'];?></p>
					</div>
				</div>
				<!-- /footer widget -->

				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">Hubungi Kami</h3>
						<ul class="list-links">
							<li><a><i class="fa fa-phone"></i> &nbsp;&nbsp; <?php echo $perusahaan['kontak_1'];?></a></li>
							<li><a><i class="fa fa-map-marker"></i> &nbsp;&nbsp; <?php echo $perusahaan['alamat_perusahaan'];?></a></li>
							<li><a><i class="fa fa-envelope-square"></i> &nbsp;&nbsp; <?php echo $perusahaan['email'];?></a></li>
							<li><a><i class="fa fa-facebook"></i> &nbsp;&nbsp; <?php echo $perusahaan['facebook'];?></a></li>
						</ul>
					</div>
				</div>
				<!-- /footer widget -->

				<div class="clearfix visible-sm visible-xs"></div>

				<!-- footer subscribe -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">BERLANGGANAN</h3>
						<p>Dengan mendaftar anda akan mendapatkan info promo, diskon & produk terbaru dari Setia Shop.</p>
						<div class="form-group">
							<input class="input" id="email" onkeyup="validateEmail(this);" name="email" placeholder="Enter Email Address">
							<p style="color: #f00; display: none;"  id="pesan">Silahkan masukkan email anda</p>
						</div>
						<button onclick="berlangganan()" id="btn_langgan" class="primary-btn">YUK BERGABUNG</button>
					</div>
				</div><!-- /footer subscribe -->
			</div>
			<!-- /row -->
			<hr>
			<!-- row -->
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<!-- footer copyright -->
					<div class="footer-copyright">
						Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Design By <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Mr Brohid</a>
					</div>
					<!-- /footer copyright -->
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</footer>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/slick.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/nouislider.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.zoom.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/main.js"></script>
	<script type="text/javascript">
		
		function backtop() {
			$("html,body").animate({scrollTop: 0}, 800);
		}

		function validateEmail(emailField){
	        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,3})$/;

	        if (reg.test(emailField.value) == false) 
	        {
	            document.getElementById("btn_langgan").disabled = true;
				$("#pesan").css({"display":"block"});
				$("#pesan").text("Karakter email anda harus terdapat @ dan (.) titik");
	        }else if (reg.test(emailField.value) == true) {
	        	document.getElementById("btn_langgan").disabled = false;
				$("#pesan").css({"display":"none"});
	        }
	        return true;
		}

		function berlangganan(){
			var emails = $("#email").val();
			if (emails == "") {
				$("#pesan").css({"display":"block"});
			}else{
				$.ajax({
					url : "<?php echo site_url('Welcome/simpan_langganan');?>",
					type : "POST",
					data : {
						email : $("#email").val()
					},
					success:function(hasil){
						alert(hasil);
						document.location='<?php echo site_url('Welcome/index');?>';
					}
				});
			}
		}
		
		function tombol_menu(){
			$("#tmp_menu").slideToggle();
		}

	</script>
</body>

</html>
