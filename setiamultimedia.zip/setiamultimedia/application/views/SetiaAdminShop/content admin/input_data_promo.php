<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Forms</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Forms</a></li>
            <li class="breadcrumb-item active">Input Data Promo</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Input Data Promo</h3>
            </div>
            <br/>
            <div class="card-body">
                <div class="basic-form">
                    <?php echo form_open_multipart('AdminBeranda/simpan_promo');?>
                        <div class="form-group">
                            <label>Kode Barang</label>
                            <input type="text" required="required" onkeyup="cari_barang()" id="kode_barang" name="kode_barang" class="form-control col-md-5" placeholder="Kode Barang">
                        </div>
                        <div class="form-group">
                            <label>Nama Barang</label>
                            <input type="text" name="harga" id="nama_barang" class="form-control col-md-7" readonly="readonly" placeholder="Nama barang">
                        </div>
                        <div class="form-group">
                            <label>Tanggal Mulai Promo</label>
                            <input type="date" name="tgl_mulai" required="required" class="form-control col-md-5" placeholder="Harga">
                        </div>
                        <div class="form-group">
                            <label>Tanggal Berakhir Promo</label>
                            <input type="date" name="tgl_akhir" class="form-control col-md-5" required="required">
                        </div>
                        <div class="form-group">
                            <label>Diskon (%)</label>
                            <input type="text" name="diskon" class="form-control col-md-5" placeholder="0 %">
                        </div>
                        <input type="submit" name="simpan" value="Simpan" class="btn btn-success">
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    
    function cari_barang(){
        $.ajax({
            url: "<?php echo site_url('AdminBeranda/cari_sesuai_kode_barang');?>",
            type : "POST",
            dataType : "json",
            data : {
                id : $("#kode_barang").val()
            },
            success:function(hasil){
                $("#nama_barang").val(hasil.nama_barang);
            }
        });
    }

</script>