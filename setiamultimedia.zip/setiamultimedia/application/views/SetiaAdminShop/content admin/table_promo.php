<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item active">Data Kategori</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Data Promo Barang</h3>
                <span><a href="<?php echo site_url('AdminBeranda/page/input_data_promo');?>" class="btn btn-info" style="float: right; margin-top: -40px;">Tambah</a></span>
            </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Barang</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Akhir</th>
                                <th>Diskon</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $no = 0;
                                foreach ($promo as $data_promo) {
                                    $no++;
                            ?>
                                   <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data_promo->nama_barang;?></td>
                                        <td><?php echo $data_promo->tgl_mulai_promo;?></td>
                                        <td><?php echo $data_promo->tgl_selesai_promo;?></td>
                                        <td><?php echo $data_promo->diskon;?></td>
                                        <td>
                                            <a href="<?php echo site_url('AdminBeranda/page/edit_kategori');?>/<?php echo $data_promo->id_promo;?>" class="btn btn-success">Edit</a>
                                            <a href="#" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
</div>
