<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Brosur Produk</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Brosur Produk</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Brosur Produk</h3>
                <span><a href="<?php echo site_url('AdminBeranda/page/edit_profile');?>" class="btn btn-danger" style="float: right; margin-top: -40px;"><i class="fa fa-reply"></i> Kembali</a></span>
                <hr>
            </div>
            <div class="table-responsive">
                <?php echo form_open('AdminBeranda/edit_brosur/'.$perusahaan['id_brosur']);?>
                <table width="100%">
                    <tr>
                        <td style="float: left;"><textarea class="col-md-5 ckeditor" id="ckedtor" name="detail"><?php echo $perusahaan['detail'];?></textarea></td>
                    </tr>
                    <tr>
                        <td style="float: left;"><br>
                            <button type="submit" class="btn btn-info"><i class="fa fa-save"></i> Simpan</a></button>
                        </td>
                    </tr>
                </table>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>
