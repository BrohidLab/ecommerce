<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)">Data Product</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)">Data Gambar Product</a></li>
            <li class="breadcrumb-item active">Edit Gambar Product</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Edit Gambar Product</h3>
            </div>
            <br/>
            <div class="card-body">
                <div class="basic-form">
                    <?php echo form_open_multipart('AdminBeranda/edit_gambar');?>
                    <div class="form-group">
                        <input type="hidden" name="id_detail" value="<?php echo $gambar['id_detail_barang'];?>" class="form-control col-md-6">
                        <input type="hidden" name="id_barang" value="<?php echo $gambar['id_barang'];?>" class="form-control col-md-6">
                        <label>Upload Gambar</label>
                        <input type="file" name="foto" class="form-control col-md-6" placeholder="Password">
                    </div>
                    <div class="form-group">
                        <label>Level Gambar</label>
                        <select class="form-control col-md-6" name="level">
                            <option <?php if($gambar['status_gambar'] == "Utama") echo "selected";?>>Utama</option>
                            <option <?php if($gambar['status_gambar'] == "Kedua") echo "selected";?>>Kedua</option>
                        </select>
                    </div>
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-success">
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
