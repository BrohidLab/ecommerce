<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item active">Data Kategori</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Data Kategori</h3>
            </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Barang</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $no = 0;
                                foreach ($kategori as $data_kategori) {
                                    $no++;
                            ?>
                                   <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data_kategori->nama_kategori;?></td>
                                        <td>
                                            <a href="<?php echo site_url('AdminBeranda/page/edit_kategori');?>/<?php echo $data_kategori->id_kategori;?>" class="btn btn-success">Edit</a>
                                            <a href="#" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
</div>
