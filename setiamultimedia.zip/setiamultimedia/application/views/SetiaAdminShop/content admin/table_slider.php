<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item active">Data Slider</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Data Slider</h3>
                <span><a href="<?php echo site_url('AdminBeranda/page/input_slider');?>" class="btn btn-info" style="float: right; margin-top: -40px;">Tambah</a></span>
            </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Judul Slide</th>
                                <th>Keterangan</th>
                                <th>Gambar</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $no = 0;
                                foreach ($slider as $data_slider) {
                                    $no++;
                            ?>
                                   <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data_slider->title;?></td>
                                        <td><?php echo $data_slider->keterangan;?></td>
                                        <td><img src="<?php echo base_url();?>assets/image_slider/<?php echo $data_slider->foto;?>" style="width: 500px; height: 250px;"></td>
                                        <td>
                                            <a href="<?php echo site_url('AdminBeranda/page/edit_kategori');?>/<?php echo $data_slider->id_slider;?>" class="btn btn-success">Edit</a>
                                            <a href="#" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
</div>
