<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Profile</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Profile Perusahaan</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Edit Profile Perusahaan</h3>
                <hr>
            </div>
            <div class="table-responsive">
                <?php echo form_open_multipart('AdminBeranda/edit_profile');?>
                <table width="100%">
                    <tr>
                        <input type="hidden" name="id_perusahaan" class="form-control col-md-7" value="<?php echo $perusahaan['id_perusahaan'];?>">
                        <td width="20%"><b>Nama Perusahaan</b></td>
                        <td> <input type="text" name="nama_perusahaan" class="form-control col-md-7" value="<?php echo $perusahaan['nama_perusahaan'];?>"></td>
                    </tr>
                    <tr>
                        <td><b>Logo Perusahaan</b></td>
                        <td style="float: left;"><img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" width="70%" style="float: left; margin: 20px auto;"> <a href="<?php echo site_url('adminberanda/page/edit_logo');?>/<?php echo $perusahaan['id_perusahaan'];?>" class="btn btn-warning"><i class="fa fa-edit" title="Ganti Logo"></i></a></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><b>Tentang Perusahaan</b></td>
                        <td style="float: left; margin: 15px auto;"><textarea class="col-md-5 ckeditor" id="ckedtor" name="tentang"><?php echo $perusahaan['tentang_perusahaan'];?></textarea></td>
                    </tr>
                    <tr>
                        <td><b>Alamat Perusahaan</b></td>
                        <td><input type="text" class="form-control col-md-12" value="<?php echo $perusahaan['alamat_perusahaan'];?>" name="alamat"></td>
                    </tr>
                    <tr>
                        <td><b>Kontak Perusahaan</b></td>
                        <td style="float: left;">:</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-5" value="<?php echo $perusahaan['kontak_1'];?>" name="kontak1" placeholder="Kontak Pertama"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-5" value="<?php echo $perusahaan['kontak_2'];?>" name="kontak2"  placeholder="Kontak Kedua"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-5" value="<?php echo $perusahaan['kontak_3'];?>" name="kontak3" placeholder="Kontak Ketiga"></td>
                    </tr>
                    <tr>
                        <td><b>Sosial Media</b></td>
                        <td style="float: left;">:</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;">Facebook</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-7" value="<?php echo $perusahaan['facebook'];?>" name="facebook" placeholder="Kontak Pertama"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;">Email</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-7" value="<?php echo $perusahaan['email'];?>" name="email" placeholder="Kontak Pertama"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;">Youtube</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-7" value="<?php echo $perusahaan['youtube'];?>" name="youtube" placeholder="Kontak Pertama"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;">Google +</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="text" class="form-control col-md-7" value="<?php echo $perusahaan['google_pless'];?>" name="google_plus" placeholder="Kontak Pertama"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <br>
                            <hr>
                            <button type="submit" class="btn btn-success" style="float: left;"><i class="fa fa-save"></i> Simpan</button>
                            <a href="<?php echo site_url('AdminBeranda/page/profile_perusahaan');?>" class="btn btn-danger" style="float: left; margin-left: 5px;"><i class="fa fa-reply"></i> Kembali</a>
                        </td>
                    </tr>
                </table>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>
