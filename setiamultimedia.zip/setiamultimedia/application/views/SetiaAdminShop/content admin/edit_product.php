<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables Data Product</a></li>
            <li class="breadcrumb-item active">Edit Product</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Edit Product</h3>
            </div>
            <br/>
            <div class="card-body">
                <div class="basic-form">
                    <?php echo form_open_multipart('AdminBeranda/edit_barang');?>
                    <div class="form-group">
                        <label>Nama Product</label>
                        <input type="text" name="nama_barang" value="<?php echo $data_product['nama_barang'];?>" class="form-control col-md-7" placeholder="Nama product">
                        <input type="hidden" name="id_barang" value="<?php echo $data_product['id_barang'];?>" class="form-control col-md-7" placeholder="Nama product">
                    </div>
                    <div class="form-group">
                        <label>Kategori Product</label>
                        <select class="form-control col-md-7" name="kategori">
                            <option>Pilih Kategori Product</option>
                            <?php
                                foreach ($kategori as $data_kategori) {
                            ?>
                                <option <?php if($data_product['kategori'] == $data_kategori->nama_kategori) echo "selected";?>><?php echo $data_kategori->nama_kategori;?></option>
                            <?php
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="text" name="harga" value="<?php echo $data_product['harga'];?>" class="form-control col-md-7" placeholder="Rp. ">
                    </div>
                    <div class="form-group">
                        <label>Detail Product</label>
                        <textarea class="col-md-5 ckeditor" id="ckedtor" name="detail_barang"><?php echo $data_product['detail_barang'];?></textarea>
                    </div>
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-success">
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
