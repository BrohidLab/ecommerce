<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Brosur Produk</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Brosur Produk</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Brosur Produk</h3>
                <span><a href="<?php echo site_url('AdminBeranda/page/edit_brosur');?>" class="btn btn-info" style="float: right; margin-top: -40px;"><i class="fa fa-edit"></i> Edit</a></span>
                <hr>
            </div>
            <div class="form-group">
                
                        <?php echo $perusahaan['detail'];?>

            </div>
        </div>
    </div>
</div>
