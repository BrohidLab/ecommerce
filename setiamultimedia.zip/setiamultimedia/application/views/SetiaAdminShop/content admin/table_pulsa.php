<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item active">Data Pulsa dan Paket Data</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Data Pulsa dan Paket Data</h3>
                <span>
                    <a href="<?php echo site_url('AdminBeranda/page/import_data');?>" class="btn btn-warning" style="float: right; top: -40px; position: relative; margin-right: 10px;">Import Data</a>
                </span>
            </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Kode Produk</th>
                                <th>Nama Kartu</th>
                                <th>Jenis Grosir</th>
                                <th>Nominal</th>
                                <th>Keterangan</th>
                                <th>Masa Aktif</th>
                                <th>Poin</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA REGULER</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregax as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregxl as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregtelkom as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregindo as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregthr as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($dataregsmr as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET DATA</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaindo_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadatelkom_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaax_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadaxl_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadathr_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpadasmr_data as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA TRANSPORTASI</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_etoll as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_gojek as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_godriv as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapultran_grab as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET SMS</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpasms_indosms as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpasms_telkomsms as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>PULSA PAKET TELEPON</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_indotel as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_telkomtel as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datapulpatel_xltel as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>TOKEN LISTRIK</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datatoli_pln as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="padding-left:20px;"><b>VOUCHER DATA</b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php
                                    
                                    $no = 0;
                                    foreach ($datavoucda_isadata as $data) {
                                        $no++;
                                ?>
                                            <tr>
                                                <td><?php echo $no;?></td>
                                                <td style="text-align:center;"><?php echo $data->kode_produk;?></td>
                                                <td><?php echo $data->kartu;?></td>
                                                <td><?php echo $data->jenis_grosir;?></td>
                                                <td><?php echo $data->nominal;?></td>
                                                <td><?php echo $data->keterangan;?></td>
                                                <td><?php echo $data->masa_aktif;?></td>
                                                <td><?php echo $data->poin;?></td>
                                                <td>
                                                    <a href="<?php echo site_url('AdminBeranda/page/edit_grosir');?>/<?php echo $data->id;?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
                                                    <br/>
                                                    <a onclick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_grosir');?>/<?php echo $data->id;?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                                </td>
                                            </tr>
                                <?php
                                    }
                                ?>
                            
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
</div>
