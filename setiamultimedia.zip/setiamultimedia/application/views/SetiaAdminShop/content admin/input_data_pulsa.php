<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Forms</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Forms</a></li>
            <li class="breadcrumb-item active">Input Data Pulsa</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Input Data Pulsa</h3>
            </div>
            <br/>
            <div class="card-body">
                <div class="basic-form">
                    <?php echo form_open_multipart('AdminBeranda/simpan_grosir');?>
                    <div class="form-group">
                        <label>Kode Produk</label>
                        <input type="text" name="kode_produk" class="form-control col-md-4" placeholder="Kode produk">
                    </div>
                    <div class="form-group">
                        <label>Kartu</label>
                        <select name="kartu" class="form-control col-md-7">
                            <option>AXIS</option>
                            <option>XL</option>
                            <option>TELKOMSEL</option>
                            <option>INDOSAT</option>
                            <option>THREE</option>
                            <option>SMART</option>
                            <option>INDOSATDATA</option>
                            <option>TELKOMSELDATA</option>
                            <option>AXISDATA</option>
                            <option>XLDATA</option>
                            <option>THREEDATA</option>
                            <option>SMARTDATA</option>
                            <option>ETOLL</option>
                            <option>GOJEK</option>
                            <option>GOJEKDRIVER</option>
                            <option>INDOSATSMS</option>
                            <option>TELKOMSELSMS</option>
                            <option>INDOSATTELEPON</option>
                            <option>TELKOMSELTELEPON</option>
                            <option>XLTELEPON</option>
                            <option>PLN</option>
                            <option>VOUCHERINDOSATDATA</option>
                            <option>TELKOMSELTELPON</option>
                            <option>AXISDATA</option>
                            <option>GRAB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jenis Grosir</label>
                        <select name="jenis_grosir" class="form-control col-md-7">
                            <option>Pulsa Paket Data</option>
                            <option>Pulsa Reguler</option>
                            <option>Pulsa Transportasi</option>
                            <option>Pulsa Paket SMS</option>
                            <option>Pulsa Paket Telepon</option>
                            <option>Token Lisktrik</option>
                            <option>Voucher Data</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nominal</label>
                        <input type="text" name="nominal" class="form-control col-md-7" placeholder="Nominal data">
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control col-md-7"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Masa Aktif</label>
                        <input type="text" name="masa_aktif" class="form-control col-md-7" placeholder="Masa aktif">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control col-md-4">
                            <option>Ada</option>
                            <option>Tidak Ada</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nilai Poin</label>
                        <input type="text" name="nilai_poin" class="form-control col-md-7" placeholder="Poin">
                    </div>
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-success">
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
