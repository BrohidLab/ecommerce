<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Profile</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Profile Perusahaan</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Profile Perusahaan</h3>
                <span><a href="<?php echo site_url('AdminBeranda/page/edit_profile');?>" class="btn btn-info" style="float: right; margin-top: -40px;"><i class="fa fa-edit"></i> Edit</a></span>
                <hr>
            </div>
            <div class="table-responsive">
                
                <table width="100%">
                    <tr>
                        <td width="20%"><b>Nama Perusahaan</b></td>
                        <td style="float: left;"><?php echo $perusahaan['nama_perusahaan'];?></td>
                    </tr>
                    <tr>
                        <td><b>Logo Perusahaan</b></td>
                        <td style="float: left;"><img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" width="70%" style="float: left; margin: 20px auto;"> </td>
                    </tr>
                    <tr>
                        <td><b>Tentang Perusahaan</b></td>
                        <td style="float: left; margin: 15px auto;"><?php echo $perusahaan['tentang_perusahaan'];?></td>
                    </tr>
                    <tr>
                        <td><b>Alamat Perusahaan</b></td>
                        <td style="float: left; margin: 20px auto;"><?php echo $perusahaan['alamat_perusahaan'];?></td>
                    </tr>
                    <tr>
                        <td><b>Kontak Perusahaan</b></td>
                        <td style="float: left;">:</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-phone"></i>  <?php echo $perusahaan['kontak_1'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-phone"></i>  <?php echo $perusahaan['kontak_2'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-phone"></i>  <?php echo $perusahaan['kontak_3'];?></td>
                    </tr>
                    <tr>
                        <td><b>Sosial Media</b></td>
                        <td style="float: left;">:</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-facebook"></i> &nbsp; <?php echo $perusahaan['facebook'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-envelope-square"></i> &nbsp; <?php echo $perusahaan['email'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-youtube"></i> &nbsp; <?php echo $perusahaan['youtube'];?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td style="float: left;"><i class="fa fa-google-plus"></i> &nbsp; <?php echo $perusahaan['google_pless'];?></td>
                    </tr>
                </table>

            </div>
        </div>
    </div>
</div>
