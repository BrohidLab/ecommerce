<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Forms</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Forms</a></li>
            <li class="breadcrumb-item active">Edit Data Pulsa</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Edit Data Pulsa</h3>
            </div>
            <br/>
            <div class="card-body">
                <div class="basic-form">
                    <?php echo form_open_multipart('AdminBeranda/proses_edit_grosir');?>
                    <div class="form-group">
                        <label>Kode Produk</label>
                        <input type="text" name="kode_produk" value="<?php echo $data_grosir['kode_produk'];?>" class="form-control col-md-4" placeholder="Kode produk">
                        <input type="hidden" name="id" value="<?php echo $data_grosir['id'];?>" class="form-control col-md-4" placeholder="Kode produk">
                    </div>
                    <div class="form-group">
                        <label>Kartu</label>
                        <input type="text" name="kartu" value="<?php echo $data_grosir['kartu'];?>" class="form-control col-md-7" placeholder="Jenis kartu">
                    </div>
                    <div class="form-group">
                        <label>Jenis Grosir</label>
                        <select name="jenis_grosir" class="form-control col-md-7">
                            <option <?php if($data_grosir['jenis_grosir'] == "Pulsa Paket Data") echo "selected";?>>Pulsa Paket Data</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Pulsa Reguler") echo "selected";?>>Pulsa Reguler</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Pulsa Transportasi") echo "selected";?>>Pulsa Transportasi</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Pulsa Paket SMS") echo "selected";?>>Pulsa Paket SMS</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Pulsa Paket Telepon") echo "selected";?>>Pulsa Paket Telepon</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Token Listrik") echo "selected";?>>Token Lisktrik</option>
                            <option <?php if($data_grosir['jenis_grosir'] == "Voucher Data") echo "selected";?>>Voucher Data</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nominal</label>
                        <input type="text" name="nominal" value="<?php echo $data_grosir['nominal'];?>" class="form-control col-md-7" placeholder="Nominal data">
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control col-md-7"><?php echo $data_grosir['keterangan'];?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Masa Aktif</label>
                        <input type="text" name="masa_aktif" class="form-control col-md-7" value="<?php echo $data_grosir['masa_aktif'];?>" placeholder="Masa aktif">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control col-md-4">
                            <option <?php if($data_grosir['status'] == "Ada") echo "selected";?>>Ada</option>
                            <option <?php if($data_grosir['status'] == "Tidak Ada") echo "selected";?>>Tidak Ada</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nilai Poin</label>
                        <input type="text" name="nilai_poin" value="<?php echo $data_grosir['poin'];?>" class="form-control col-md-7" placeholder="Poin">
                    </div>
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-success">
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
