<!-- Bread crumb -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Dashboard</h3> </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
</div>
<!-- End Bread crumb -->
<div class="row">
    <div class="col-md-3">
        <div class="card p-30">
            <div class="media">
                <div class="media-left meida media-middle">
                    <span><i class="fa fa-bitbucket-square f-s-40 color-primary"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2>
                        <?php
                            $jumak = $this->db->query("SELECT * FROM table_barang Where kategori = 'Aksesoris'")->num_rows();
                            echo $jumak;
                        ?>
                    </h2>
                    <p class="m-b-0">Produk Aksesoris</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-30">
            <div class="media">
                <div class="media-left meida media-middle">
                    <span><i class="fa fa-mobile-phone f-s-40 color-success"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2><?php
                            $jumak = $this->db->query("SELECT * FROM table_barang Where kategori = 'Handphone'")->num_rows();
                            echo $jumak;
                        ?></h2>
                    <p class="m-b-0">Produk Handphone</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-30">
            <div class="media">
                <div class="media-left meida media-middle">
                    <span><i class="fa fa-credit-card f-s-40 color-warning"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2><?php
                            $jumak = $this->db->query("SELECT * FROM table_barang Where kategori = 'Kartu Perdana'")->num_rows();
                            echo $jumak;
                        ?></h2>
                    <p class="m-b-0">Produk Kartu Perdana</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-30">
            <div class="media">
                <div class="media-left meida media-middle">
                    <span><i class="fa fa-list f-s-40 color-danger"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2><?php
                            $jumak = $this->db->query("SELECT * FROM table_barang Where kategori = 'Lain-lain'")->num_rows();
                            echo $jumak;
                        ?></h2>
                    <p class="m-b-0">Produk Lain-lain</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    
    <div class="col-md-12">
        <div class="card p-30">
            <h3>Informasi</h3>
            <hr>
            <p>Silahkan isi data dengan benar dan lengkap..</p>
        </div>
    </div>
</div>
</div>