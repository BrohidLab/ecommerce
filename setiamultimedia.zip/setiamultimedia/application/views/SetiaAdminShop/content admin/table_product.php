<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-primary">Tables</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Tables</a></li>
            <li class="breadcrumb-item active">Data Product</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h3>Data Product</h3>
            </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Barang</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Detail Barang</th>
                                <th>Foto</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $no = 0;
                                foreach ($data_barang as $barang) {
                                    $no++;
                            ?>
                                   <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $barang->nama_barang;?></td>
                                        <td><?php echo $barang->kategori;?></td>
                                        <td>Rp. <?php echo number_format($barang->harga, 0,".",".");?></td>
                                        <td><?php echo substr($barang->detail_barang, 0, 400);?>....</td>
                                        <td><img src="<?php echo base_url();?>/gambar_product/<?php echo $barang->gambar;?>" width="100px" height="100px"></td>
                                        <td>
                                            <a href="<?php echo site_url('AdminBeranda/page/edit_product');?>/<?php echo $barang->id_barang;?>" class="btn btn-success">Edit</a>
                                            <a onClick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('AdminBeranda/hapus_product');?>/<?php echo $barang->id_barang;?>" class="btn btn-danger">Delete</a>
                                            <a href="<?php echo site_url('AdminBeranda/page/table_gambar');?>/<?php echo $barang->id_barang;?>" class="btn btn-info" style="margin-top: 5px;">View Gambar Product</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
</div>
