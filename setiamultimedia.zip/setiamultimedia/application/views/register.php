<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>SETIA MULTIMEDIA - Register Akun Setia Shop</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />

	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-login.css">
	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick.css" />
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" />
    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/Admin layout/css/helper.css" rel="stylesheet">
    
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<div id="top-header">
			<div class="container">
				<div class="pull-left">
					<span>Welcome to SETIA SHOP!</span>
				</div>
				<div class="pull-right">
					<span><i class="fa fa-phone"></i> &nbsp; <?php echo $perusahaan['kontak_1'];?></span>
				</div>
			</div>
		</div>
		<!-- /top Header -->

		<!-- header -->
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<!-- Logo -->
					<div class="header-logo">
						<a class="logo" href="<?php echo site_url('Welcome/index');?>">
							<img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" style="width: 250px;" alt="">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Search -->
					<div class="header-search">
						<?php echo form_open_multipart('Welcome/proses_cari');?>
							<input class="input search-input" name="cari" type="text" placeholder="Enter your keyword">
							<select class="input search-categories" name="kategori">
								<option>Pilih Semua</option>
								<?php 
									foreach ($kategori as $data_kategori) {
								?>
									<option><?php echo $data_kategori->nama_kategori;?></option>
								<?php
									}
								?>
							</select>
							<button class="search-btn"><i class="fa fa-search"></i></button>
						<?php echo form_close();?>
					</div>
					<!-- /Search -->
				</div>
				<div class="pull-right">
					<ul class="header-btns">
						<!-- Account -->
						<li class="header-account dropdown default-dropdown">
							<div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-user-o"></i>
								</div>
								<strong class="text-uppercase">My Account <i class="fa fa-caret-down"></i></strong>
							</div>
							<ul class="custom-menu">
								<?php 
									$user_login = $this->session->userdata('email');
									if (empty($user_login)) {
								?>
										<li><a href="<?php echo site_url('Welcome/login');?>"><i class="fa fa-unlock-alt"></i> Login</a></li>
										<li><a href="<?php echo site_url('Welcome/register');?>"><i class="fa fa-user-plus"></i> Create An Account</a></li>
								<?php
									}else{
								?>
										<li><a href="#"><i class="fa fa-user-o"></i> My Account</a></li>
										<li><a href="#"><i class="fa fa-heart-o"></i> My Wishlist</a></li>
										<li><a href="#"><i class="fa fa-check"></i> Checkout</a></li>
										<li><a href="<?php echo site_url('Welcome/logout');?>"><i class="fa fa-sign-out"></i> Log Out</a></li>	
								<?php
									}
								?>
								
							</ul>
						</li>
						<!-- /Account -->

						<!-- Cart -->
						<li class="header-cart dropdown default-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-shopping-cart"></i>
									<span class="qty">3</span>
								</div>
								<strong class="text-uppercase">My Cart:</strong>
								<br>
								<span>35.20$</span>
							</a>
							<div class="custom-menu">
								<div id="shopping-cart">
									<div class="shopping-cart-list">
										<div class="product product-widget">
											<div class="product-thumb">
												<img src="<?php echo base_url();?>assets/img/thumb-product01.jpg" alt="">
											</div>
											<div class="product-body">
												<h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
												<h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
											</div>
											<button class="cancel-btn"><i class="fa fa-trash"></i></button>
										</div>
										<div class="product product-widget">
											<div class="product-thumb">
												<img src="<?php echo base_url();?>assets/img/thumb-product01.jpg" alt="">
											</div>
											<div class="product-body">
												<h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
												<h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
											</div>
											<button class="cancel-btn"><i class="fa fa-trash"></i></button>
										</div>
									</div>
									<div class="shopping-cart-btns">
										<button class="main-btn">View Cart</button>
										<button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button>
									</div>
								</div>
							</div>
						</li>
						<!-- /Cart -->

						<!-- Mobile nav toggle-->
						<li class="nav-toggle">
							<button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
						</li>
						<!-- / Mobile nav toggle -->
					</ul>
				</div>
			</div>

		</div>
			<!-- header -->
	</header>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav show-on-click">
					<span class="category-header">Categories <i class="fa fa-list"></i></span>
					<ul class="category-list">						
						<li><a href="#">Pulsa Operator</a></li>
						<?php 
							foreach ($kategori as $data_kategori) {
						?>
							<li><a href="<?php echo site_url('Welcome/product');?>/<?php echo $data_kategori->nama_kategori;?>"><?php echo $data_kategori->nama_kategori;?></a></li>
						<?php
							}
						?>
					</ul>
				</div>
				<!-- /category nav -->

			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->


	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">


				<div class="row" style="margin:30px auto">
				    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
						<?php echo form_open_multipart('Welcome/simpan_user');?>
							<fieldset>
								<div class="judul_login">Buat Akun Setia Shop Anda</div>
								<hr class="colorgraph">
								<div class="form-group">
									<span>Nama Lengkap*</span>
				                    <input type="text" name="nama_lengkap" id="nama" class="form-control input-lg" placeholder="Nama Lengkap" required="required">
								</div>
								<div class="form-group">
									<span>Alamat Email*</span>
				                    <input type="email" name="email" id="email" required="required" class="form-control input-lg" placeholder="Mohon isi alamat email anda">
								</div>
								<div class="form-group">
									<span>Kata sandi*</span>
				                    <input type="password" name="password" onkeyup="input_katasandi(this)" id="password" class="form-control input-lg" required="required" placeholder="Mohon masukkan kata sandi anda minimal 6 karakter">
				                    <p  style="color: #ff6666; display: none;" id="katasandi">Kata sandi anda terlalu pendek, minimal kata sandi anda 6 karakter.</p>
								</div>
								<div class="form-group">
									<span>Tulis ulang kata sandi*</span>
				                    <input type="password" name="ulangpassword" required="required" id="ulang" class="form-control input-lg" onkeyup="input_ulangsandi()" placeholder="Masukkan ulang kata sandi anda">
				                    <p style="color: #ff6666; display: none;" id="ulangsandi">Kata sandi anda tidak sama, silahkan cek lagi.</p>
								</div>
								<div class="form-group">
									<span>Tanggal lahir*</span>
				                    <input type="date" name="tgl_lahir" required="required" class="form-control input-lg" required="required">
								</div>
								<div class="form-group">
									<span>Jenis kelamin*</span>
				                    <select class="form-control input-lg" required="required" name="jenis_kelamin">
				                    	<option value="">Pilih</option>
				                    	<option>Laki-laki</option>
				                    	<option>Wanita</option>
				                    </select>
								</div>
								<hr class="colorgraph">
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-12">
										<input type="submit" class="btn btn-lg btn-primary btn-block" value="Register">
									</div>
									<span class="perintah">You have account Setia Shop!</span>
									<div class="col-xs-12 col-sm-12 col-md-12">
				                        <a href="<?php echo site_url('Welcome/login');?>" class="btn btn-lg btn-success btn-block">Sign In</a>
									</div>
								</div>
							</fieldset>
						<?php echo form_close();?>
					</div>
				</div>
				
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
	<footer id="footer" class="section section-grey">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<!-- footer logo -->
						<div class="footer-logo">
							<a class="logo" href="<?php echo site_url('Welcome/index');?>">
					            <img src="<?php echo base_url();?>assets/img/<?php echo $perusahaan['logo'];?>" alt="">
				          	</a>
						</div>
						<!-- /footer logo -->

						<p><?php echo $perusahaan['tentang_perusahaan'];?></p>
					</div>
				</div>
				<!-- /footer widget -->

				<!-- footer widget -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">Hubungi Kami</h3>
						<ul class="list-links">
							<li><a><i class="fa fa-phone"></i> &nbsp;&nbsp; <?php echo $perusahaan['kontak_1'];?></a></li>
							<li><a><i class="fa fa-map-marker"></i> &nbsp;&nbsp; <?php echo $perusahaan['alamat_perusahaan'];?></a></li>
							<li><a><i class="fa fa-envelope-square"></i> &nbsp;&nbsp; <?php echo $perusahaan['email'];?></a></li>
							<li><a><i class="fa fa-facebook"></i> &nbsp;&nbsp; <?php echo $perusahaan['facebook'];?></a></li>
						</ul>
					</div>
				</div>
				<!-- /footer widget -->

				<div class="clearfix visible-sm visible-xs"></div>

				<!-- footer subscribe -->
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer-header">BERLANGGANAN</h3>
						<p>Dengan mendaftar anda akan mendapatkan info promo, diskon & produk terbaru dari Setia Shop.</p>
						<div class="form-group">
							<input class="input" id="email" onkeyup="validateEmail(this);" name="email" placeholder="Enter Email Address">
							<p style="color: #f00; display: none;"  id="pesan">Silahkan masukkan email anda</p>
						</div>
						<button onclick="berlangganan()" id="btn_langgan" class="primary-btn">YUK BERGABUNG</button>
					</div>
				</div>
				<!-- /footer subscribe -->
			</div>
			<!-- /row -->
			<hr>
			<!-- row -->
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<!-- footer copyright -->
					<div class="footer-copyright">
						Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Design By <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Mr Brohid</a>
					</div>
					<!-- /footer copyright -->
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</footer>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/slick.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/nouislider.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.zoom.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/main.js"></script>

	<script type="text/javascript">
		
		function input_katasandi(sandi){
			if (sandi.value.length < 6) {
				$("#katasandi").css({"display":"block"});
			}else{
				$("#katasandi").css({"display":"none"});
			}

			input_ulangsandi();
		}

		function input_ulangsandi(){
			var sandi = $("#password").val();
			var ulangsandi = $("#ulang").val();

			if (sandi != ulangsandi) {
				$("#ulangsandi").css({"display":"block"});
			}else{
				$("#ulangsandi").css({"display":"none"});
			}
		}

		function validateEmail(emailField){
	        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,3})$/;

	        if (reg.test(emailField.value) == false) 
	        {
	            document.getElementById("btn_langgan").disabled = true;
				$("#pesan").css({"display":"block"});
				$("#pesan").text("Karakter email anda harus terdapat @ dan (.) titik");
	        }else if (reg.test(emailField.value) == true) {
	        	document.getElementById("btn_langgan").disabled = false;
				$("#pesan").css({"display":"none"});
	        }
	        return true;
		}

		function berlangganan(){
			var emails = $("#email").val();
			if (emails == "") {
				$("#pesan").css({"display":"block"});
			}else{
				$.ajax({
					url : "<?php echo site_url('Welcome/simpan_langganan');?>",
					type : "POST",
					data : {
						email : $("#email").val()
					},
					success:function(hasil){
						alert(hasil);
						document.location='<?php echo site_url('Welcome/index');?>';
					}
				});
			}
		}

	</script>

</body>
</html>
