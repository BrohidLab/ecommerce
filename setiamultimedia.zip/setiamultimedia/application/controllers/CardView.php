<?php

	/**
	 * 
	 */
	class CardView extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('M_setia_shop');
		}

		function index(){
			$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
			$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
			$this->load->view("view_card", $data);
		}
	}

?>