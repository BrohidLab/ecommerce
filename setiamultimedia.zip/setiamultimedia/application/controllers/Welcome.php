<?php
class Welcome extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->library('cart');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -	
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function index()
	{
		$data['page1'] = $this->M_setia_shop->tampil_barang()->result();
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['slider'] = $this->M_setia_shop->tampil_slide()->result();
		$data['all_product'] = $this->M_setia_shop->tampil_semua_product()->result();
		$data['product_diskon'] = $this->M_setia_shop->tampil_dengan_diskon()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('Index', $data);
	}

	function product(){
		$kategori = $this->uri->segment(3);
		$harga_min = $this->uri->segment(4);
		$harga_max = $this->uri->segment(5);

		if ($kategori == "Pilih%20semua") {
			$kategori = "";
			if (empty($harga_min) && empty($harga_max)) {
				$data['data_product'] = $this->M_setia_shop->tampil_sesuai_product($kategori)->result();
			}else{
				$data['data_product'] = $this->M_setia_shop->proses_filter_harga($kategori, $harga_min, $harga_max)->result();
			}
		}else{
			if (empty($harga_min) && empty($harga_max)) {
				$data['data_product'] = $this->M_setia_shop->tampil_sesuai_product($kategori)->result();
			}else{
				$data['data_product'] = $this->M_setia_shop->proses_filter_harga($kategori, $harga_min, $harga_max)->result();
			}
		}
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('product', $data);
	}

	function tambah($id){
		$ambildata = $this->M_setia_shop->getData($id)->row();
		$data = array(
				'id' => $ambildata->id_barang,
				'qty' => 1,
				'price' => $ambildata->harga,
				'name' => 'bisa'
			);
		$this->cart->insert($data);
		echo "<script>document.location = document.referrer</script>";
	}

	function sort_by(){
		$pilih = $this->input->post("pilihan");
		$session = array(
				'sort' => $pilih
			);
		$this->session->set_userdata($session);
		redirect(base_url());
	}

	function pulsa_paket_data(){
		$data['paket'] = $this->M_setia_shop->tampil_paket()->result();
		$data['pulsa'] = $this->M_setia_shop->tampil_pulsa()->result();
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('pulsa&paket_data', $data);
	}

	function detail_product(){
		$kode = $this->uri->segment(3);
		$kode_barang = substr($kode, 13, 9);
		$data['barang'] = $this->M_setia_shop->tampil_detail_barang($kode_barang)->row_array();
		$data['gambar'] = $this->M_setia_shop->tampil_detail_gambar($kode_barang)->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$this->load->view('product_page', $data);
	}

	function login(){
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('login', $data);
	}

	function register(){
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('register', $data);
	}

	function proses_cari(){
		$cari = $this->input->post('cari');
		$kategori = $this->input->post('kategori');
		if ($kategori == "Pilih Semua") {
			$kat = "";
			$session = array(
					'pencarian' => $cari,
					'kat_pencarian' => $kat
				);
			$this->session->set_userdata($session);
			redirect(base_url('index.php/Welcome/pencarian_product')."/".$kategori."/".$cari);

		}else{
			$kat = $kategori;
			$session = array(
					'pencarian' => $cari,
					'kat_pencarian' => $kat
				);
			$this->session->set_userdata($session);
			redirect(base_url('index.php/Welcome/pencarian_product')."/".$kategori."/".$cari);
		}
	}

	function pencarian_product(){
		$cari = $this->session->userdata('pencarian');
		$kategori = $this->session->userdata('kat_pencarian');
		$min_harga = $this->uri->segment(5);
		$max_harga = $this->uri->segment(6);
		if (empty($min_harga) && empty($max_harga)) {
			$data['data_product'] = $this->M_setia_shop->pencarian_barang($cari, $kategori)->result();
		}else{
			$data['data_product'] = $this->M_setia_shop->filter_pencarian_barang($cari, $kategori, $min_harga, $max_harga)->result();
		}
		$data['kategori'] = $this->M_setia_shop->tampil_kategori()->result();
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$this->load->view('pencarian_product', $data);
	}

	function simpan_user(){
		$nama_lengkap = $this->input->post('nama_lengkap');
		$tanggal_lahir = $this->input->post('tgl_lahir');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$ulangpassword = $this->input->post('ulangpassword');
		$tanggal_register = date("Y-m-d");

		if (strlen($password) < 6) {
			echo "<script>alert('Minimal password anda 6 karakter, silahkan coba lagi.')</script>";
			echo "<script>document.location='register'</script>";
		}else if ($password != $ulangpassword) {
			echo "<script>alert('Kata sandi anda tidak sama, silahkan coba lagi.')</script>";
			echo "<script>document.location='register'</script>";
		}else{
			$data_user = array(
						'id_user' => null,
						'nama_lengkap' => $nama_lengkap,
						'tanggal_lahir' => $tanggal_lahir,
						'jenis_kelamin' => $jenis_kelamin,
						'email' => $email,
						'password' => $password,
						'tanggal_register' => $tanggal_register
					);

			$proses_simpan = $this->M_setia_shop->simpan_user($data_user);
			if ($proses_simpan) {
				echo "<script>alert('Berhasil mendaftar silahkan login.')</script>";
				echo "<script>document.location='login'</script>";
			}else{
				echo "<script>alert('Data anda masih failed.')</script>";
				echo "<script>document.location='register'</script>";
			}
		}
	}

	function kelola_login(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$data_login = array(
						'email' => $email,
						'password' => $password
					);

		$kelola_login = $this->M_setia_shop->proses_login($data_login)->num_rows();
		if ($kelola_login > 0) {
			$session = array(
					'email' => $email
				);
			$this->session->set_userdata($session);
			echo "<script>alert('Berhasil login.')</script>";
			echo "<script>document.location='index'</script>";
		}else{
			echo "<script>alert('Akun anda belum terdaftar.')</script>";
			echo "<script>document.location='login'</script>";
		}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('index.php/Welcome/index'));
	}

	function proses_filter_harga(){
		$kategori = $this->input->post('kategori');
		$mulai = $this->input->post('min_harga');
		$selesai = $this->input->post('max_harga');
		
		if (empty($kategori)) {
		 	$kategori = 'Pilih semua';
		 	echo "<script>document.location='product/$kategori/$mulai/$selesai'</script>";
		 	$session = array(
					'kategori' => $kategori
				);
			$this->session->set_userdata($session);
		 }else{
		 	echo "<script>document.location='product/$kategori/$mulai/$selesai'</script>";
		 	$session = array(
					'kategori' => $kategori
				);
			$this->session->set_userdata($session);
		 }	
	}

	function proses_filter_pencarian_harga(){
		$kategori = $this->input->post('kat_pencarian');
		$mulai = $this->input->post('min_harga');
		$selesai = $this->input->post('max_harga');
		$cari = $this->session->userdata('pencarian');
		$session = array(
				'kategori' => $kategori
			);
		$this->session->set_userdata($session);
		
		if (empty($kategori)) {
		 	$kategori = 'Pilih semua';
			redirect(base_url('index.php/Welcome/pencarian_product')."/".$kategori."/".$cari."/".$mulai."/".$selesai);
		 }else{
		 	redirect(base_url('index.php/Welcome/pencarian_product')."/".$kategori."/".$cari."/".$mulai."/".$selesai);
		 }	
	}

	function simpan_langganan(){
		$email = $this->input->post('email');
		$data = array(
				'id_langganan' => null,
				'email' => $email
			);

		$simpan = $this->M_setia_shop->simpan_langganan($data);
		if ($simpan) {
			echo "Email anda berhasil terdaftar..";
		}else{
			echo "Maaf silahkan coba nanti lagi..";
		}
	}

	function grosir_pulsa(){
		$data['data_pulsa'] = $this->M_setia_shop->tampil_grosir_pulsa()->result();
		
		//data pulsa reguler
		$data['dataregax'] = $this->M_setia_shop->tampil_pulsaregax()->result();
		$data['dataregxl'] = $this->M_setia_shop->tampil_pulsaregxl()->result();
		$data['dataregtelkom'] = $this->M_setia_shop->tampil_pulsaregtelkom()->result();
		$data['dataregindo'] = $this->M_setia_shop->tampil_pulsaregindo()->result();
		$data['dataregthr'] = $this->M_setia_shop->tampil_pulsaregthr()->result();
		$data['dataregsmr'] = $this->M_setia_shop->tampil_pulsaregsmr()->result();
		
		//data pulsa paket data
		$data['datapulpadaindo_data'] = $this->M_setia_shop->tampil_pulpadaindo_data()->result();
		$data['datapulpadatelkom_data'] = $this->M_setia_shop->tampil_pulpadatelkom_data()->result();
		$data['datapulpadaax_data'] = $this->M_setia_shop->tampil_pulpadaax_data()->result();
		$data['datapulpadaxl_data'] = $this->M_setia_shop->tampil_pulpadaxl_data()->result();
		$data['datapulpadathr_data'] = $this->M_setia_shop->tampil_pulpadathr_data()->result();
		$data['datapulpadasmr_data'] = $this->M_setia_shop->tampil_pulpadasmr_data()->result();
		
		//data pulsa transportasi
		$data['datapultran_etoll'] = $this->M_setia_shop->tampil_pultran_etoll()->result();
		$data['datapultran_gojek'] = $this->M_setia_shop->tampil_pultran_gojek()->result();
		$data['datapultran_godriv'] = $this->M_setia_shop->tampil_pultran_godriv()->result();
		$data['datapultran_grab'] = $this->M_setia_shop->tampil_pultran_grab()->result();
		
		//data pulsa paket sms
		$data['datapulpasms_indosms'] = $this->M_setia_shop->tampil_pulpasms_indosms()->result();
		$data['datapulpasms_telkomsms'] = $this->M_setia_shop->tampil_pulpasms_telkomsms()->result();
		
		//data pulsa paket telpon
		$data['datapulpatel_indotel'] = $this->M_setia_shop->tampil_pulpatel_indotel()->result();
		$data['datapulpatel_telkomtel'] = $this->M_setia_shop->tampil_pulpatel_telkomtel()->result();
		$data['datapulpatel_xltel'] = $this->M_setia_shop->tampil_pulpatel_xltel()->result();
		
		//data token listrik
		$data['datatoli_pln'] = $this->M_setia_shop->tampil_toli_pln()->result();
		
		//data voucher data
		$data['datavoucda_isadata'] = $this->M_setia_shop->tampil_voucda_isadata()->result();
		
		
		$data['perusahaan'] = $this->M_setia_shop->tampil_profile()->row_array();
		$data['brosur'] = $this->M_proses_admin->tampil_brosur()->row_array();
		$this->load->view('grosir_pulsa', $data);
	}
}
