<?php

	/**
	* 
	*/
	class AdminSetiaShop extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('m_login');
		}

		function index(){
			$this->load->view('SetiaAdminShop/login');
		}

		function home(){
			redirect(base_url('index.php/adminberanda/page/dashboard'));
		}

		function proses_login(){
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$data = array(
				'username' => $username,
				'password' => $password
			);

			$cek = $this->m_login->cek_login("table_admin", $data);
			if ($cek->num_rows() > 0) {
				$session = array(
						'username' => $username
					);
				$this->session->set_userdata($session);
				redirect(base_url('index.php/AdminBeranda/page/dashboard'));
			}else{
				echo "<script>alert('Username dan Password yang anda masukkan salah...!');</script>";
				echo "<script>document.location='index'</script>";
			}
		}

		function logout(){
			$this->session->sess_destroy();
			redirect(base_url('index.php/AdminSetiaShop/index'));
		}
	}

?>