<?php
	
	/**
	* 
	*/
	class AdminBeranda extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('M_proses_admin');
		}

		function index(){
			$this->load->view('SetiaAdminShop/Index');
		}

		function page($page){
			$data['page'] = $page;
			if($page == "dashboard"){
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "input_product") {
				$data['kategori'] = $this->M_proses_admin->tampil_kategori()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_product") {
				$data['data_barang'] = $this->M_proses_admin->tampil_barang()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_gambar") {
				$barang = $this->uri->segment(4);
				$data['gambar'] = $this->M_proses_admin->tampil_gambar_barang($barang)->result();
				$data['nama_barang'] = $this->M_proses_admin->tampil_gambar_barang($barang)->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "upload_gambar") {
				$barang = $this->uri->segment(4);
				$data['nama_barang'] = $this->M_proses_admin->tampil_gambar_barang($barang)->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "input_kategori") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_kategori") {
				$data['kategori'] = $this->M_proses_admin->tampil_kategori()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_kategori") {
				$id = $this->uri->segment(4);
				$data['data_kategori'] = $this->M_proses_admin->tampil_edit_kategori($id)->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_product") {
				$id = $this->uri->segment(4);
				$data['data_product'] = $this->M_proses_admin->tampil_edit_product($id)->row_array();
				$data['kategori'] = $this->M_proses_admin->tampil_kategori()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_gambar") {
				$id = $this->uri->segment(4);
				$data['gambar'] = $this->M_proses_admin->tampil_edit_gambar($id)->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "input_slider") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_slider") {
				$data['slider'] = $this->M_proses_admin->tampil_slider()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "input_data_pulsa") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_pulsa") {
				$data['pulsa'] = $this->M_proses_admin->tampil_pulsa()->result();
				//data pulsa reguler
        		$data['dataregax'] = $this->M_setia_shop->tampil_pulsaregax()->result();
        		$data['dataregxl'] = $this->M_setia_shop->tampil_pulsaregxl()->result();
        		$data['dataregtelkom'] = $this->M_setia_shop->tampil_pulsaregtelkom()->result();
        		$data['dataregindo'] = $this->M_setia_shop->tampil_pulsaregindo()->result();
        		$data['dataregthr'] = $this->M_setia_shop->tampil_pulsaregthr()->result();
        		$data['dataregsmr'] = $this->M_setia_shop->tampil_pulsaregsmr()->result();
        		
        		//data pulsa paket data
        		$data['datapulpadaindo_data'] = $this->M_setia_shop->tampil_pulpadaindo_data()->result();
        		$data['datapulpadatelkom_data'] = $this->M_setia_shop->tampil_pulpadatelkom_data()->result();
        		$data['datapulpadaax_data'] = $this->M_setia_shop->tampil_pulpadaax_data()->result();
        		$data['datapulpadaxl_data'] = $this->M_setia_shop->tampil_pulpadaxl_data()->result();
        		$data['datapulpadathr_data'] = $this->M_setia_shop->tampil_pulpadathr_data()->result();
        		$data['datapulpadasmr_data'] = $this->M_setia_shop->tampil_pulpadasmr_data()->result();
        		
        		//data pulsa transportasi
        		$data['datapultran_etoll'] = $this->M_setia_shop->tampil_pultran_etoll()->result();
        		$data['datapultran_gojek'] = $this->M_setia_shop->tampil_pultran_gojek()->result();
        		$data['datapultran_godriv'] = $this->M_setia_shop->tampil_pultran_godriv()->result();
        		$data['datapultran_grab'] = $this->M_setia_shop->tampil_pultran_grab()->result();
        		
        		//data pulsa paket sms
        		$data['datapulpasms_indosms'] = $this->M_setia_shop->tampil_pulpasms_indosms()->result();
        		$data['datapulpasms_telkomsms'] = $this->M_setia_shop->tampil_pulpasms_telkomsms()->result();
        		
        		//data pulsa paket telpon
        		$data['datapulpatel_indotel'] = $this->M_setia_shop->tampil_pulpatel_indotel()->result();
        		$data['datapulpatel_telkomtel'] = $this->M_setia_shop->tampil_pulpatel_telkomtel()->result();
        		$data['datapulpatel_xltel'] = $this->M_setia_shop->tampil_pulpatel_xltel()->result();
        		
        		//data token listrik
        		$data['datatoli_pln'] = $this->M_setia_shop->tampil_toli_pln()->result();
        		
        		//data voucher data
        		$data['datavoucda_isadata'] = $this->M_setia_shop->tampil_voucda_isadata()->result();
        		
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "input_data_promo") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "table_promo") {
				$data['promo'] = $this->M_proses_admin->tampil_promo_barang()->result();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "profile_perusahaan") {
				$data['perusahaan'] = $this->M_proses_admin->tampil_profile()->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_profile") {
				$data['perusahaan'] = $this->M_proses_admin->tampil_profile()->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_logo") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "brosur_produk") {
				$data['perusahaan'] = $this->M_proses_admin->tampil_brosur()->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_brosur") {
				$data['perusahaan'] = $this->M_proses_admin->tampil_brosur()->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "edit_grosir") {
			    $id_grosir = $this->uri->segment(4);
			    $data['data_grosir'] = $this->M_proses_admin->tampil_grosir_edit($id_grosir)->row_array();
				$this->load->view('SetiaAdminShop/Index',$data);
			}else if ($page == "import_data") {
				$this->load->view('SetiaAdminShop/Index',$data);
			}
		}

		function simpan_barang(){
			$sql = $this->M_proses_admin->tampil_kode_nomor_barang()->row_array();
			if (empty($sql['id_barang'])) {
				$nomor = "KDB100001";
			}else{
				$id = $sql['id_barang'];
				$jum = substr($id, 3) + 1;
				$nomor = "KDB".$jum; 
			}

			$nama_barang = $this->input->post('nama_barang');
			$kategori = $this->input->post('kategori');
			$harga = $this->input->post('harga');
			$detail_barang = $this->input->post('detail_barang');

			$config['upload_path'] = "./gambar_product/";
			$config['allowed_types'] = "gif|jpg|png";
			$config['max_size'] = 1100;
			$config['max_width'] = 3580;
			$config['max_height'] = 2768;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("foto")) {
				$error = $this->upload->display_errors();
				echo "<script>alert('$error')</script>";
				echo "<script>document.location='page/input_master_barang'</script>";
			}else{
				$file = $this->upload->data();
				$data_barang = array(
						'id_detail_barang' => null,
						'id_barang' => $nomor,
						'gambar' => $file['file_name'],
						'status_gambar' => 'Utama'
					);

				$this->M_proses_admin->simpan_gambar($data_barang);

				$data = array(
					'id_barang' => $nomor,
					'nama_barang' => $nama_barang,
					'kategori' => $kategori,
					'harga' => $harga,
					'detail_barang' => $detail_barang,
					'status_diskon' => 'Non Aktif'
				);

				$simpan_barang = $this->M_proses_admin->simpan_barang($data);
				if ($simpan_barang) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='page/input_product'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='page/input_product'</script>";
				}
			}
		}
		
		function edit_grosir(){
			$kode_produk = $this->input->post('kode_produk');
			$kartu = $this->input->post('kartu');
			$jenis_grosir = $this->input->post('jenis_grosir');
			$nominal = $this->input->post('nominal');
			$keterangan = $this->input->post('keterangan');
			$masa_aktif = $this->input->post('masa_aktif');
			$status = $this->input->post('status');
			$poin = $this->input->post('nilai_poin');
			$id = $this->input->post('id');

			$data = array(
					'kode_produk' => $kode_produk,
					'kartu' => $kartu,
					'jenis_grosir' => $jenis_grosir,
					'nominal' => $nominal,
					'keterangan' => $keterangan,
					'masa_aktif' => $masa_aktif,
					'status' => $status,
					'poin' => $poin
				);

			$edit_data = $this->M_proses_admin->edit_grosir($data, $id);
			if ($edit_data) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/table_pulsa'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/edit_data_pulsa'</script>";
			}
		}
		
		function cari_produk(){
			$kode = $this->input->post('id');
			$data_grosir = $this->M_proses_admin->pencarian_produk($kode)->row();
			$jumlah = $this->M_proses_admin->pencarian_produk($kode)->num_rows();
			if ($jumlah > 0) {
				$hasil = array(
					'id' => $data_grosir->id,
					'kartu' => $data_grosir->kartu,
					'jenis_grosir' => $data_grosir->jenis_grosir,
					'nominal' => $data_grosir->nominal,
					'keterangan' => $data_grosir->keterangan,
					'masa_aktif' => $data_grosir->masa_aktif,
					'status' => $data_grosir->status,
					'poin' => $data_grosir->poin
				);
				echo json_encode($hasil);
			}else{
				$hasil = array(
					'id' => "",
					'kartu' => "",
					'jenis_grosir' => "",
					'nominal' => "",
					'keterangan' => "",
					'masa_aktif' => "",
					'status' => "",
					'poin' => ""
				);
				echo json_encode($hasil);
			}
			
		}

		function edit_brosur($id){
			$detail = $this->input->post('detail');
			$data = array(
					'detail' => $detail
				);

			$simpan = $this->M_proses_admin->edit_brosur($data, $id);
			if ($simpan) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='../page/brosur_produk'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='../page/edit_brosur'</script>";
				}
		}

		function simpan_pulsa(){
			$nama_operator = $this->input->post('nama_operator');
			$jenis_paket = $this->input->post('jenis_paket');
			$harga = $this->input->post('harga');
			$jumlah = $this->input->post('jumlah');

			$data = array(
					'id_pulsa' => null,
					'nama_operator' => $nama_operator,
					'jenis_pulsa' => $jenis_paket,
					'harga_jual' => $harga,
					'jumlah_pulsa_atau_data' => $jumlah
				);

			$simpan = $this->M_proses_admin->simpan_pulsa($data);
			if ($simpan) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/input_data_pulsa'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/input_data_pulsa'</script>";
			}
		}

		function simpan_grosir(){
			$kode_produk = $this->input->post('kode_produk');
			$kartu = $this->input->post('kartu');
			$jenis_grosir = $this->input->post('jenis_grosir');
			$nominal = $this->input->post('nominal');
			$keterangan = $this->input->post('keterangan');
			$masa_aktif = $this->input->post('masa_aktif');
			$status = $this->input->post('status');
			$poin = $this->input->post('nilai_poin');

			$data = array(
					'kode_produk' => $kode_produk,
					'kartu' => $kartu,
					'jenis_grosir' => $jenis_grosir,
					'nominal' => $nominal,
					'keterangan' => $keterangan,
					'masa_aktif' => $masa_aktif,
					'status' => $status,
					'poin' => $poin
				);

			$simpan_data = $this->M_proses_admin->simpan_grosir($data);
			if ($simpan_data) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/input_data_pulsa'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/input_data_pulsa'</script>";
			}
		}

		function edit_barang(){
			$nama_barang = $this->input->post('nama_barang');
			$id_barang = $this->input->post('id_barang');
			$kategori = $this->input->post('kategori');
			$harga = $this->input->post('harga');
			$detail_barang = $this->input->post('detail_barang');

			$data = array(
				'nama_barang' => $nama_barang,
				'kategori' => $kategori,
				'harga' => $harga,
				'detail_barang' => $detail_barang
			);

			$edit_data = array(
					'nama_barang' => $nama_barang
				);

			$simpan_barang = $this->M_proses_admin->edit_barang($data, $id_barang);
			if ($simpan_barang) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/table_product'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/edit_product/$id_barang'</script>";
			}
		}

		function simpan_kategori(){
			$nama_kategori = $this->input->post('nama_kategori');

			$data = array(
				'id_kategori' => null,
				'nama_kategori' => $nama_kategori
			);

			$simpan = $this->M_proses_admin->simpan_kategori($data);
			if ($simpan) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/input_kategori'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/input_kategori'</script>";
			}
		}

		function edit_kategori(){
			$nama_kategori = $this->input->post('nama_kategori');
			$id_kategori = $this->input->post('id_kategori');

			$data = array(
				'nama_kategori' => $nama_kategori
			);

			$simpan = $this->M_proses_admin->edit_kategori($data, $id_kategori);
			if ($simpan) {
				echo "<script>alert('Berhasil Tersimpan')</script>";
				echo "<script>document.location='page/table_kategori'</script>";
			}else{
				echo "<script>alert('Gagal Tersimpan')</script>";
				echo "<script>document.location='page/edit_kategori/$id_kategori'</script>";
			}
		}

		function upload_gambar(){
			$id_barang = $this->input->post('id_barang');

			$config['upload_path'] = "./gambar_product/";
			$config['allowed_types'] = "gif|jpg|png";
			$config['max_size'] = 1100;
			$config['max_width'] = 1080;
			$config['max_height'] = 568;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("foto")) {
				$error = $this->upload->display_errors();
				echo "<script>alert('$error')</script>";
				echo "<script>document.location='page/upload_gambar/$id_barang'</script>";
			}else{
				$file = $this->upload->data();
				$data = array(
					'id_detail_barang' => null,
					'id_barang' => $id_barang,
					'gambar' => $file['file_name'],
					'status_gambar' => 'Kedua'
				);

				$simpan_barang = $this->M_proses_admin->simpan_gambar($data);
				if ($simpan_barang) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='page/table_gambar/$id_barang'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='page/upload_gambar/$id_barang'</script>";
				}
			}	
		}

		function simpan_slider(){
			$title = $this->input->post('title');
			$keterangan = $this->input->post('keterangan');

			$config['upload_path'] = "./assets/image_slider/";
			$config['allowed_types'] = "gif|jpg|png|jpeg";
			$config['max_size'] = 1100;
			$config['max_width'] = 1080;
			$config['max_height'] = 768;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("foto")) {
				$error = $this->upload->display_errors();
				echo "<script>alert('$error')</script>";
				echo "<script>document.location='page/input_slider'</script>";
			}else{
				$file = $this->upload->data();
				$data = array(
					'id_slider' => null,
					'title' => $title,
					'keterangan' => $keterangan,
					'foto' => $file['file_name']
				);

				$simpan_barang = $this->M_proses_admin->simpan_slider($data);
				if ($simpan_barang) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='page/table_slider'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='page/input_slider'</script>";
				}
			}	
		}

		function edit_logo(){
			$id_perusahaan = $this->input->post('id_perusahaan');

			$config['upload_path'] = "./assets/img/";
			$config['allowed_types'] = "gif|jpg|png|jpeg";
			$config['max_size'] = 1100;
			$config['max_width'] = 1080;
			$config['max_height'] = 768;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("foto")) {
				$error = $this->upload->display_errors();
				echo "<script>alert('$error')</script>";
				echo "<script>document.location='page/edit_logo'</script>";
			}else{
				$file = $this->upload->data();
				$data = array(
					'logo' => $file['file_name']
				);

				$simpan = $this->M_proses_admin->edit_profile($data, $id_perusahaan);
				if ($simpan) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='page/edit_profile'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='page/edit_logo'</script>";
				}
			}	
		}

		function edit_gambar(){
			$id_detail_barang = $this->input->post('id_detail');
			$id_barang = $this->input->post('id_barang');
			$level = $this->input->post('level');

			$config['upload_path'] = "./gambar_product/";
			$config['allowed_types'] = "gif|jpg|png";
			$config['max_size'] = 1100;
			$config['max_width'] = 1080;
			$config['max_height'] = 568;

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("foto")) {
				$error = $this->upload->display_errors();
				echo "<script>alert('$error')</script>";
				echo "<script>document.location='page/edit_gambar/$id_detail_barang'</script>";
			}else{
				$file = $this->upload->data();
				$data = array(
					'gambar' => $file['file_name'],
					'status_gambar' => $level
				);

				$simpan_barang = $this->M_proses_admin->edit_gambar($data, $id_detail_barang);
				if ($simpan_barang) {
					echo "<script>alert('Berhasil Tersimpan')</script>";
					echo "<script>document.location='page/table_gambar/$id_barang'</script>";
				}else{
					echo "<script>alert('Gagal Tersimpan')</script>";
					echo "<script>document.location='page/upload_gambar/$id_detail_barang'</script>";
				}
			}	
		}

		function hapus_gambar(){
			$id_barang = $this->uri->segment(3);
			$where = $this->uri->segment(4);
			$hapus = $this->M_proses_admin->hapus_gambar($where);

			if ($hapus) {
				echo "<script>alert('Data berhasil terhapus..')</script>";
				echo "<script>document.location='../../page/table_gambar/$id_barang'</script>";
			}else{
				echo "<script>alert('Data gagal terhapus..')</script>";
				echo "<script>document.location='../../page/table_gambar/$id_barang'</script>";
			}
		}

		function hapus_grosir(){
			$id = $this->uri->segment(3);
			$hapus = $this->M_proses_admin->hapus_grosir($id);

			if ($hapus) {
				echo "<script>alert('Data berhasil terhapus..')</script>";
				echo "<script>document.location='../page/table_pulsa'</script>";
			}else{
				echo "<script>alert('Data gagal terhapus..')</script>";
				echo "<script>document.location='../page/table_pulsa'</script>";
			}
		}

		function hapus_product(){
			$id_barang = $this->uri->segment(3);
			$this->M_proses_admin->hapus_semua_gambar($id_barang);
			$hapus = $this->M_proses_admin->hapus_product($id_barang);

			if ($hapus) {
				echo "<script>alert('Data berhasil terhapus..')</script>";
				echo "<script>document.location='../page/table_product'</script>";
			}else{
				echo "<script>alert('Data gagal terhapus..')</script>";
				echo "<script>document.location='../page/table_product'</script>";
			}
		}

		function cari_sesuai_kode_barang(){
			$kode = $this->input->post('id');
			$data_barang = $this->M_proses_admin->tampil_cari_barang($kode)->row();
			$hasil = array(
					'nama_barang' => $data_barang->nama_barang
				);
			echo json_encode($hasil);
		}

		function simpan_promo(){
			$kode_barang = $this->input->post('kode_barang');
			$tgl_mulai = $this->input->post('tgl_mulai');
			$tgl_akhir = $this->input->post('tgl_akhir');
			$diskon = $this->input->post('diskon');

			$cek_data_promo = $this->M_proses_admin->cek_barang_promo($kode_barang)->num_rows();
			if ($cek_data_promo > 0) {
				echo "<script>alert('Mohon maaf data ini sudah ada pada data promo silahkan cek di table promo..')</script>";
				echo "<script>document.location='page/table_promo'</script>";
			}else{
				$cek_barang = $this->M_proses_admin->tampil_cari_barang($kode_barang)->num_rows();
				if ($cek_barang) {
					echo "<script>alert('Mohon maaf data ini sudah ada pada data promo silahkan cek di table promo..')</script>";
					echo "<script>document.location='page/table_promo'</script>";
				}else{
					$data_promo = array(
							'id_promo' => null,
							'id_barang' => $kode_barang,
							'tgl_mulai_promo' => $tgl_mulai,
							'tgl_selesai_promo' => $tgl_akhir,
							'diskon' => $diskon
						);

					$data_update_status = array(
							'status_diskon' => 'Aktif'
						);

					$this->db->M_proses_admin->update_status_promo_barang($data_update_status, $kode_barang); 

					$simpan_promo = $this->M_proses_admin->simpan_promo($data_promo);
					if ($simpan_promo) {
						echo "<script>alert('Data berhasil tersimpan..')</script>";
						echo "<script>document.location='page/table_promo'</script>";
					}else{
						echo "<script>alert('Data gagal tersimpan..')</script>";
						echo "<script>document.location='page/input_data_promo'</script>";
					}
				}				
			}

		}

		function edit_profile(){
			$id_perusahaan = $this->input->post('id_perusahaan');
			$nama_perusahaan = $this->input->post('nama_perusahaan');
			$tentang_perusahaan = $this->input->post('tentang');
			$alamat = $this->input->post('alamat');
			$kontak1 = $this->input->post('kontak1');
			$kontak2 = $this->input->post('kontak2');
			$kontak3 = $this->input->post('kontak3');
			$facebook = $this->input->post('facebook');
			$email = $this->input->post('email');
			$youtube = $this->input->post('youtube');
			$googleples = $this->input->post('google_plus');

			$data_perusahaan = array(
						'nama_perusahaan' => $nama_perusahaan,
						'tentang_perusahaan' => $tentang_perusahaan,
						'alamat_perusahaan' => $alamat,
						'kontak_1' => $kontak1,
						'kontak_2' => $kontak2,
						'kontak_3' => $kontak3,
						'facebook' => $facebook,
						'email' => $email,
						'youtube' => $youtube,
						'google_pless' => $googleples
					);
			$edit = $this->M_proses_admin->edit_profile($data_perusahaan, $id_perusahaan);
			if ($edit) {
				echo "<script>alert('Data berhasil tersimpan..')</script>";
				echo "<script>document.location='page/profile_perusahaan'</script>";
			}else{
				echo "<script>alert('Data gagal tersimpan..')</script>";
				echo "<script>document.location='page/edit_profile'</script>";
			}


		}
		
		function proses_edit_grosir(){
		    $id = $this->input->post('id');
		    $kode_produk = $this->input->post('kode_produk');
			$kartu = $this->input->post('kartu');
			$jenis_grosir = $this->input->post('jenis_grosir');
			$nominal = $this->input->post('nominal');
			$keterangan = $this->input->post('keterangan');
			$masa_aktif = $this->input->post('masa_aktif');
			$status = $this->input->post('status');
			$poin = $this->input->post('nilai_poin');

			$data = array(
					'kode_produk' => $kode_produk,
					'kartu' => $kartu,
					'jenis_grosir' => $jenis_grosir,
					'nominal' => $nominal,
					'keterangan' => $keterangan,
					'masa_aktif' => $masa_aktif,
					'status' => $status,
					'poin' => $poin
				);

			$simpan_data = $this->M_proses_admin->edit_grosir($data, $id);
			if ($simpan_data) {
				echo "<script>alert('Success')</script>";
				echo "<script>document.location='page/table_pulsa'</script>";
			}else{
				echo "<script>alert('Failed!')</script>";
				echo "<script>document.location='page/edit_grosir/$id'</script>";
			}
		}
	}

?>